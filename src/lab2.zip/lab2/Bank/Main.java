/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package Bank;

/**
 *
 * @author tai.tran
 */
public class Main {

    public static void main(String[] args) {
        Bank bank = new Bank();
        bank.Input();
        bank.Print();
        bank.Deposit1Account();
    }
}
