/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package lab2;

/**
 *
 * @author Student
 */
public class Lab2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Complex cp1 = new Complex(1,2);
        Complex cp2 = new Complex(3,4);
        Complex result = cp1.Plus(cp2);
        result.Print();
    }
}
    
